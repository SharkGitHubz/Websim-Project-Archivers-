class SongUploadManager {
  constructor(soundtrackManager) {
    this.soundtrackManager = soundtrackManager;
    this.uploadedSongs = [];
    this.pinnedSong = null;
    this.room = new WebsimSocket();
    
    this.initializeEventListeners();
    this.loadSavedSongs();
    this.loadPinnedSong();
  }

  async loadSavedSongs() {
    // Subscribe to song records
    this.room.collection('song').subscribe(songs => {
      this.uploadedSongs = songs;
      this.renderUploadedSongs();
    });
  }

  async loadPinnedSong() {
    // Subscribe to pinned song records
    this.room.collection('pinned_song').subscribe(pins => {
      // Get the most recent pin
      const sortedPins = pins.sort((a, b) => 
        new Date(b.created_at) - new Date(a.created_at)
      );
      
      if (sortedPins.length > 0) {
        this.pinnedSong = sortedPins[0];
        // Play the pinned song
        const pinnedSongData = this.uploadedSongs.find(s => s.id === this.pinnedSong.song_id);
        if (pinnedSongData) {
          this.playSong(pinnedSongData);
        }
        this.renderUploadedSongs();
      }
    });
  }

  initializeEventListeners() {
    const songUploadButton = document.getElementById('song-upload-button');
    const songUploadModal = document.getElementById('song-upload-modal');
    const closeButton = songUploadModal.querySelector('.close');
    const songFileInput = document.getElementById('song-file-input');

    songUploadButton.addEventListener('click', () => {
      songUploadModal.style.display = 'block';
    });

    closeButton.addEventListener('click', () => {
      songUploadModal.style.display = 'none';
    });

    songFileInput.addEventListener('change', async (e) => {
      const files = Array.from(e.target.files);
      for (const file of files) {
        await this.addSongToPlaylist(file);
      }
    });

    window.addEventListener('click', (event) => {
      if (event.target === songUploadModal) {
        songUploadModal.style.display = 'none';
      }
    });
  }

  async addSongToPlaylist(file) {
    try {
      // Upload file to S3
      const url = await websim.upload(file);
      
      // Create song record
      await this.room.collection('song').create({
        name: file.name,
        url: url
      });
    } catch (error) {
      console.error('Error uploading song:', error);
      alert('Failed to upload song. Please try again.');
    }
  }

  async pinSong(song) {
    try {
      // Delete any existing pins
      const existingPins = await this.room.collection('pinned_song').getList();
      for (const pin of existingPins) {
        if (pin.username === this.room.party.client.username) {
          await this.room.collection('pinned_song').delete(pin.id);
        }
      }

      // Create new pin
      await this.room.collection('pinned_song').create({
        song_id: song.id
      });

      // Play the song immediately
      this.playSong(song);
    } catch (error) {
      console.error('Error pinning song:', error);
      alert('Failed to pin song. Please try again.');
    }
  }

  async unpinSong(song) {
    try {
      const existingPins = await this.room.collection('pinned_song').getList();
      for (const pin of existingPins) {
        if (pin.username === this.room.party.client.username && pin.song_id === song.id) {
          await this.room.collection('pinned_song').delete(pin.id);
        }
      }
    } catch (error) {
      console.error('Error unpinning song:', error);
      alert('Failed to unpin song. Please try again.');
    }
  }

  renderUploadedSongs() {
    const uploadedSongsList = document.getElementById('uploaded-songs-list');
    uploadedSongsList.innerHTML = '';

    this.uploadedSongs.forEach((song) => {
      const songElement = document.createElement('div');
      songElement.classList.add('playlist-song');
      
      const nameSpan = document.createElement('span');
      nameSpan.textContent = song.name;
      
      const buttonsContainer = document.createElement('div');
      buttonsContainer.style.display = 'flex';
      buttonsContainer.style.gap = '4px';

      const playButton = document.createElement('button');
      playButton.textContent = 'Play';
      playButton.addEventListener('click', () => {
        this.playSong(song);
      });
      
      const pinButton = document.createElement('button');
      pinButton.classList.add('pin-button');
      const isPinned = this.pinnedSong && this.pinnedSong.song_id === song.id;
      pinButton.textContent = isPinned ? '📌' : '📍';
      if (isPinned) {
        pinButton.classList.add('active');
        songElement.classList.add('pinned');
      }
      
      pinButton.addEventListener('click', () => {
        if (isPinned) {
          this.unpinSong(song);
        } else {
          this.pinSong(song);
        }
      });
      
      // Only show remove button for songs uploaded by the current user
      if (song.username === this.room.party.client.username) {
        const removeButton = document.createElement('button');
        removeButton.textContent = '🗑️';
        removeButton.addEventListener('click', async () => {
          await this.removeSong(song);
        });
        buttonsContainer.appendChild(removeButton);
      }
      
      songElement.appendChild(nameSpan);
      buttonsContainer.appendChild(playButton);
      buttonsContainer.appendChild(pinButton);
      songElement.appendChild(buttonsContainer);
      
      uploadedSongsList.appendChild(songElement);
    });
  }

  playSong(song) {
    // Update soundtrack manager to play this specific song
    this.soundtrackManager.playCustomSong(song.url);
  }

  async removeSong(song) {
    try {
      // If this song is pinned, unpin it first
      if (this.pinnedSong && this.pinnedSong.song_id === song.id) {
        await this.unpinSong(song);
      }
      await this.room.collection('song').delete(song.id);
    } catch (error) {
      console.error('Error removing song:', error);
      alert('Failed to remove song. Please try again.');
    }
  }
}

// We'll modify the existing soundtrack manager to support custom song playback
document.addEventListener('DOMContentLoaded', () => {
  const soundtrackManager = new SoundtrackManager([
    '/Mii Editor - Mii Maker (Wii U) Music [ ezmp3.cc ].mp3'
  ]);
  
  const songUploadManager = new SongUploadManager(soundtrackManager);
});