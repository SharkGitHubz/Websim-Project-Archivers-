class LiveChatManager {
  constructor() {
    this.messages = [];
    this.moderationAI = new ModerationAI();
    this.generalAI = new GeneralAI();
    this.username = null;
    this.room = new WebsimSocket();

    // Subscribe to chat messages
    this.room.collection('chat_message').subscribe(messages => {
      this.messages = messages;
      this.renderMessages();
    });
  }

  async promptForUsername() {
    let username = '';
    while (!username.trim()) {
      username = prompt('Please enter your username:');
      if (username === null) {
        // User clicked cancel, generate random username
        username = `Viewer${Math.floor(Math.random() * 10000)}`;
      }
    }
    this.username = username;
    return username;
  }

  async sendMessage(message) {
    if (!this.username) {
      this.username = await this.promptForUsername();
    }

    // Check for AI chat commands
    if (message.startsWith('/ai ') || message.startsWith(';ai ')) {
      return await this.handleAICommand(message);
    }

    const moderationResult = await this.moderationAI.moderate(message);
    
    if (moderationResult.isClean) {
      // Add message to database
      await this.room.collection('chat_message').create({
        username: this.username,
        message: message,
        timestamp: new Date(),
        moderated: false
      });
      return true;
    } else {
      // Add moderated message
      await this.room.collection('chat_message').create({
        username: this.username,
        message: '[Message removed by moderator]',
        timestamp: new Date(),
        moderated: true
      });
      return false;
    }
  }

  async handleAICommand(message) {
    // Extract the actual prompt by removing the command prefix
    const prompt = message.startsWith('/ai ') ? message.slice(4) : message.slice(4);
    
    try {
      const aiResponse = await this.generalAI.generateResponse(prompt);
      
      // Add both the user's command and AI's response to chat
      await this.room.collection('chat_message').create({
        username: this.username,
        message: message,
        timestamp: new Date(),
        moderated: false
      });

      await this.room.collection('chat_message').create({
        username: 'General AI',
        message: aiResponse,
        timestamp: new Date(),
        moderated: false
      });

      return true;
    } catch (error) {
      console.error('AI Command Error:', error);
      
      await this.room.collection('chat_message').create({
        username: 'System',
        message: 'Sorry, I couldn\'t process the AI command right now.',
        timestamp: new Date(),
        moderated: false
      });
      
      return false;
    }
  }

  renderMessages() {
    const liveChatMessages = document.getElementById('live-chat-messages');
    liveChatMessages.innerHTML = '';

    this.messages.slice(-50).forEach(msg => {
      const messageElement = document.createElement('div');
      messageElement.classList.add('live-chat-message');
      messageElement.classList.add(msg.moderated ? 'moderated' : 'user');
      
      const timestamp = new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
      messageElement.textContent = `${timestamp} ${msg.username}: ${msg.message}`;
      
      if (msg.username === 'General AI') {
        messageElement.classList.add('ai-response');
      }

      // Highlight current user's messages
      if (msg.username === this.username) {
        messageElement.classList.add('own-message');
      }
      
      liveChatMessages.appendChild(messageElement);
    });

    // Scroll to bottom
    liveChatMessages.scrollTop = liveChatMessages.scrollHeight;
  }
}

class ModerationAI {
  async moderate(message) {
    try {
      const response = await fetch('/api/ai_completion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({ 
          prompt: `Moderate a live chat message for a stray cat livestream. 
                   Determine if the message is truly offensive or harmful, 
                   not just containing mild language.
                   
                   Rules:
                   - Allow words like "shit", "fuck", "stupid", "dumb", "damn", "noob" if used casually
                   - "noob" is considered a very mild term in gaming/internet culture and should never be censored
                   - Block messages that are:
                     1. Directly insulting individuals with hate or malice
                     2. Hate speech
                     3. Explicitly sexual content
                     4. Threats
                     5. Aggressive or targeting language
                   
                   Examples of acceptable messages:
                   - "wtf that cat is so cute"
                   - "what a noob, didn't even see the cat"
                   - "damn that's a lot of cats"
                   - "this feeding station is fucking awesome"
                   
                   Examples of unacceptable messages:
                   - "I hate you, you're worthless"
                   - [explicit hate speech or slurs]
                   - [sexually explicit content]
                   - "I'm going to hurt you"
                   
                   interface ModerationResult {
                     isClean: boolean;
                     reason?: string;
                   }
                   {
                     "isClean": true,
                     "reason": null
                   }
                   {
                     "isClean": false,
                     "reason": "Directly threatening another user"
                   }`,
          data: { 
            message: message,
            context: "Live chat for a stray cat livestream website with feeding stations" 
          }
        }),
      });
      
      const data = await response.json();
      return {
        isClean: data.isClean !== false,
        reason: data.reason
      };
    } catch (error) {
      console.error('Moderation error:', error);
      return { isClean: true }; // Default to allowing message
    }
  }
}

class GeneralAI {
  constructor() {
    this.systemPrompt = `You are a highly capable AI assistant in a live chat for a WebSim project that embeds the Meow Camera website (meow.camera) in an iframe. 

Key Context About the Website:
- This is a live webcam site showing stray cats in human-made feeding chambers in China
- The website features three main tabs: 
  1. Feeders with hungry cats
  2. Featured feeders
  3. Popular feeders
- Located in the left corner is a search bar to find specific cat feeding chambers
- Feeding stations are carefully constructed to support stray cat populations
- Unique feature: Users can donate via a mobile app to drop more food via a dispenser
- Cats can enter and exit these feeding chambers freely
- All feeding chambers are located in China

Your role is to:
1. Discuss the cats, their environment, and the feeding stations
2. Share insights about stray cat care and community support
3. Explain the purpose of the human-built feeding areas
4. Engage viewers with compassionate and educational responses related to the livestream
5. Be helpful and conversational while maintaining awareness of the specific context of this live chat and website

When discussing the website, demonstrate knowledge about its purpose of supporting and documenting stray cat populations through carefully designed live camera feeds and feeding stations.`;
    
    this.messages = [
      { role: 'system', content: this.systemPrompt }
    ];
  }

  async generateResponse(userMessage) {
    this.messages.push({ role: 'user', content: userMessage });
    
    try {
      const response = await fetch('/api/ai_completion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({ 
          prompt: `Provide a conversational and engaging response to the user's message in the context of the Meow Camera livestream. 
                   Focus on the stray cats, feeding stations, and the unique features of this website.
                   
                   interface Response {
                     reply: string;
                   }
                   {
                     "reply": "That's a fascinating observation! The feeding chambers here are designed to give stray cats a safe, comfortable space to eat. Did you know users can even donate to help provide more food?"
                   }`,
          data: { messages: this.messages }
        }),
      });
      
      const data = await response.json();
      const aiReply = data.reply;
      
      this.messages.push({ role: 'assistant', content: aiReply });
      return aiReply;
    } catch (error) {
      console.error('Error fetching AI response:', error);
      return 'Sorry, I encountered an error processing your message about the Meow Camera livestream.';
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const liveChatButton = document.getElementById('live-chat-button');
  const liveChatModal = document.getElementById('live-chat-modal');
  const closeButtons = document.querySelectorAll('.close');
  const liveChatInput = document.getElementById('live-chat-input');
  const liveChatSendButton = document.getElementById('live-chat-send-button');

  const liveChatManager = new LiveChatManager();

  liveChatButton.addEventListener('click', () => {
    liveChatModal.style.display = 'block';
  });

  closeButtons.forEach(closeBtn => {
    closeBtn.addEventListener('click', () => {
      liveChatModal.style.display = 'none';
    });
  });

  window.addEventListener('click', (event) => {
    if (event.target === liveChatModal) {
      liveChatModal.style.display = 'none';
    }
  });

  async function sendLiveMessage() {
    const message = liveChatInput.value.trim();
    if (message) {
      const isClean = await liveChatManager.sendMessage(message);
      
      if (isClean) {
        liveChatInput.value = '';
      }
    }
  }

  liveChatSendButton.addEventListener('click', sendLiveMessage);
  liveChatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      sendLiveMessage();
    }
  });
});