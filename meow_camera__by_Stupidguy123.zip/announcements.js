class AnnouncementSystem {
  constructor() {
    this.room = new WebsimSocket();
    this.setupWebSocket();
    
    // Initialize after DOM is fully loaded
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        this.initializeUI();
        this.checkCreatorAccess();
      });
    } else {
      this.initializeUI();
      this.checkCreatorAccess();
    }
  }

  async checkCreatorAccess() {
    try {
      // Get the creator's username
      const creator = await window.websim.getCreatedBy();
      const currentUser = await window.websim.getUser();
      
      // Only show the announcement button to the creator
      const announcementButton = document.getElementById('announcement-button');
      if (currentUser && creator && currentUser.username === creator.username) {
        announcementButton.style.display = 'flex';
      } else {
        announcementButton.style.display = 'none';
      }
    } catch (error) {
      console.error('Error checking creator access:', error);
    }
  }

  initializeUI() {
    // Get UI elements
    const announcementButton = document.getElementById('announcement-button');
    const announcementModal = document.getElementById('announcement-modal');
    const closeButton = announcementModal.querySelector('.close');
    const sendButton = document.getElementById('send-announcement-button');
    const announcementText = document.getElementById('announcement-text');

    // Verify elements exist before adding listeners
    if (!announcementButton || !announcementModal || !closeButton || !sendButton || !announcementText) {
      console.error('Required announcement UI elements not found');
      return;
    }

    announcementButton.addEventListener('click', () => {
      announcementModal.style.display = 'block';
    });

    closeButton.addEventListener('click', () => {
      announcementModal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
      if (event.target === announcementModal) {
        announcementModal.style.display = 'none';
      }
    });

    sendButton.addEventListener('click', async () => {
      const text = announcementText.value.trim();
      if (text) {
        const creator = await window.websim.getCreatedBy();
        const currentUser = await window.websim.getUser();
        
        if (currentUser && creator && currentUser.username === creator.username) {
          this.sendAnnouncement(text);
          announcementText.value = '';
          announcementModal.style.display = 'none';
        } else {
          alert('Only the website creator can send announcements.');
        }
      }
    });
  }

  setupWebSocket() {
    // Listen for announcement events
    this.room.onmessage = (event) => {
      if (event.data.type === 'announcement') {
        this.showAnnouncement(event.data.text);
      }
    };
  }

  async sendAnnouncement(text) {
    try {
      // Send the announcement to all connected clients
      this.room.send({
        type: 'announcement',
        text: text
      });
    } catch (error) {
      console.error('Error sending announcement:', error);
      alert('Failed to send announcement. Please try again.');
    }
  }

  showAnnouncement(text) {
    const container = document.getElementById('announcement-container');
    if (!container) {
      console.error('Announcement container not found');
      return;
    }

    container.textContent = text;
    container.style.display = 'block';

    // Hide the announcement after 10 seconds
    setTimeout(() => {
      container.style.display = 'none';
    }, 10000);
  }
}

// Initialize the announcement system
const announcementSystem = new AnnouncementSystem();