class SoundtrackManager {
  constructor(tracks) {
    this.tracks = tracks;
    this.audio = new Audio();
    this.currentTrackIndex = 0;
    this.isPlaying = true;
    this.customTracks = [];
    this.room = new WebsimSocket();

    // Bind methods
    this.startMusic = this.startMusic.bind(this);
    this.onTrackEnded = this.onTrackEnded.bind(this);

    // Load saved songs and pinned song
    this.loadSavedSongs();
  }

  async loadSavedSongs() {
    // Subscribe to song records
    this.room.collection('song').subscribe(songs => {
      this.customTracks = songs.map(song => song.url);
    });

    // Subscribe to pinned song records
    this.room.collection('pinned_song').subscribe(pins => {
      // Get the most recent pin
      const sortedPins = pins.sort((a, b) => 
        new Date(b.created_at) - new Date(a.created_at)
      );
      
      if (sortedPins.length > 0) {
        const pinnedSongId = sortedPins[0].song_id;
        // Find the song data
        const songs = this.room.collection('song').getList();
        const pinnedSong = songs.find(s => s.id === pinnedSongId);
        if (pinnedSong) {
          this.playCustomSong(pinnedSong.url);
        }
      } else {
        // If no pinned song, start with default tracks
        this.startMusic();
      }
    });
  }

  startMusic() {
    if (this.isPlaying) {
      // Prefer custom tracks if available, otherwise use default tracks
      const trackSource = this.customTracks.length > 0 
        ? this.customTracks[this.currentTrackIndex] 
        : this.tracks[this.currentTrackIndex];
      
      this.audio.src = trackSource;
      this.audio.addEventListener('ended', this.onTrackEnded);
      this.audio.play().catch(error => {
        console.error('Error playing track:', error);
      });
    }
  }

  onTrackEnded() {
    // Move to next track, mixing custom and default tracks
    if (this.customTracks.length > 0) {
      this.currentTrackIndex = (this.currentTrackIndex + 1) % this.customTracks.length;
    } else {
      this.currentTrackIndex = (this.currentTrackIndex + 1) % this.tracks.length;
    }
    this.startMusic();
  }

  playCustomSong(songUrl) {
    // Play a specific song
    this.audio.src = songUrl;
    this.audio.play().catch(error => {
      console.error('Error playing track:', error);
    });
  }

  start() {
    this.startMusic();
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const tracks = [
    '/Mii Editor - Mii Maker (Wii U) Music [ ezmp3.cc ].mp3'
  ];

  const soundtrackManager = new SoundtrackManager(tracks);
});