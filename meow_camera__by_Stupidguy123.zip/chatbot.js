class AIAssistant {
  constructor() {
    this.systemPrompt = `You are an AI assistant specifically contextual to the Meow Camera website (meow.camera) which shows live webcams of stray cats being fed in China. 

Key Context:
- The website displays live camera feeds of stray cats in various locations across China
- All feeding stations and cameras are located in China
- The feeding stations are human-constructed to support local stray cat populations
- At the left corner of the screen, users can select various cameras to view different feeding chambers
- These cats are being fed in designated feeding areas that have been carefully set up
- The website features three main tabs: 
  1. Feeders with hungry cats
  2. Featured feeders
  3. Popular feeders
- Unique feature: Users can donate via a mobile app to drop more food via dispensers
- Your role is to:
  1. Discuss the cats, their environment, and the feeding stations in China
  2. Share insights about stray cat care and community support in China
  3. Explain the purpose of the human-built feeding areas
  4. Provide interesting information about the different camera views
  5. Engage viewers with compassionate and educational responses related to the livestream

When discussing the website, be knowledgeable about its purpose of supporting and documenting stray cat populations in China through carefully designed live camera feeds and feeding stations.`;
    
    this.messages = [
      { role: 'system', content: this.systemPrompt }
    ];
  }

  async generateResponse(userMessage) {
    this.messages.push({ role: 'user', content: userMessage });
    
    try {
      const response = await fetch('/api/ai_completion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify({ 
          prompt: `Provide a conversational and engaging response based on the conversation history about the Meow Camera website. 
                   Focus on stray cats, feeding, and compassionate animal care.
                   
                   interface Response {
                     reply: string;
                   }
                   {
                     "reply": "That's a great observation about the cats! Community feeding programs like this are so important for supporting stray cat populations."
                   }`,
          data: { messages: this.messages }
        }),
      });
      
      const data = await response.json();
      const aiReply = data.reply;
      
      this.messages.push({ role: 'assistant', content: aiReply });
      return aiReply;
    } catch (error) {
      console.error('Error fetching AI response:', error);
      return 'Sorry, I encountered an error processing your message about the Meow Camera.';
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const chatButton = document.getElementById('ai-chat-button');
  const chatModal = document.getElementById('ai-chat-modal');
  const closeButton = document.querySelector('.close');
  const chatMessages = document.getElementById('chat-messages');
  const userInput = document.getElementById('user-input');
  const sendButton = document.getElementById('send-button');
  
  const aiAssistant = new AIAssistant();

  chatButton.addEventListener('click', () => {
    chatModal.style.display = 'block';
  });

  closeButton.addEventListener('click', () => {
    chatModal.style.display = 'none';
  });

  window.addEventListener('click', (event) => {
    if (event.target === chatModal) {
      chatModal.style.display = 'none';
    }
  });

  function addMessage(message, type) {
    const messageElement = document.createElement('div');
    messageElement.textContent = message;
    messageElement.classList.add(type);
    chatMessages.appendChild(messageElement);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  async function sendMessage() {
    const message = userInput.value.trim();
    if (message) {
      addMessage(message, 'user-message');
      userInput.value = '';
      
      const aiResponse = await aiAssistant.generateResponse(message);
      addMessage(aiResponse, 'ai-message');
    }
  }

  sendButton.addEventListener('click', sendMessage);
  userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });
});