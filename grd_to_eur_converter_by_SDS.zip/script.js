const GRD_TO_EUR_RATE = 0.0029347029;

const grdInput = document.getElementById('grdAmount');
const eurOutput = document.getElementById('eurAmount');

let countUp = new CountUp('eurAmount', 0, {
  decimal: '.',
  decimals: 2,
  duration: 1,
});

function convertGRDtoEUR(amount) {
  return (amount * GRD_TO_EUR_RATE).toFixed(2);
}

function updateConversion() {
  const grdAmount = parseFloat(grdInput.value) || 0;
  const eurAmount = parseFloat(convertGRDtoEUR(grdAmount));
  
  // Animate the number change
  countUp.update(eurAmount);
  
  // Add highlight animation
  eurOutput.classList.remove('highlight');
  void eurOutput.offsetWidth; // Trigger reflow
  eurOutput.classList.add('highlight');
}

grdInput.addEventListener('input', updateConversion);

// Initial conversion
updateConversion();

// Initialize CountUp
countUp.start();