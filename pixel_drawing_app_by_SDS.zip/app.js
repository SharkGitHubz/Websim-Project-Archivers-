class PixelDrawingApp {
  constructor() {
    this.canvas = document.getElementById('pixelCanvas');
    this.colorPicker = document.getElementById('colorPicker');
    this.eraserBtn = document.getElementById('eraser');
    this.clearBtn = document.getElementById('clear');
    this.sizeSelect = document.getElementById('canvasSize');
    this.themeToggle = document.getElementById('themeToggle');
    this.brushSize = document.getElementById('brushSize');
    this.brushSizeValue = document.getElementById('brushSizeValue');
    this.colorHistory = document.getElementById('colorHistory');
    this.pencilBtn = document.getElementById('pencil');
    this.fillBucketBtn = document.getElementById('fillBucket');
    this.saveBtn = document.getElementById('save');
    
    this.isDrawing = false;
    this.currentColor = this.colorPicker.value;
    this.currentTool = 'pencil';
    this.colorHistoryArray = [];
    
    this.setupEventListeners();
    this.createCanvas(parseInt(this.sizeSelect.value));
    this.setupThemeToggle();
    this.setupBrushPreview();
  }

  setupEventListeners() {
    // Canvas drawing events
    this.canvas.addEventListener('mousedown', () => this.isDrawing = true);
    document.addEventListener('mouseup', () => this.isDrawing = false);
    document.addEventListener('mouseleave', () => this.isDrawing = false);
    
    // Tool controls
    this.colorPicker.addEventListener('input', (e) => {
      this.currentColor = e.target.value;
      this.addToColorHistory(e.target.value);
      this.setTool('pencil');
    });
    
    this.eraserBtn.addEventListener('click', () => this.setTool('eraser'));
    this.pencilBtn.addEventListener('click', () => this.setTool('pencil'));
    this.fillBucketBtn.addEventListener('click', () => this.setTool('fill'));
    this.clearBtn.addEventListener('click', () => this.clearCanvas());
    this.saveBtn.addEventListener('click', () => this.saveAsPNG());
    
    this.sizeSelect.addEventListener('change', (e) => {
      this.createCanvas(parseInt(e.target.value));
    });

    this.brushSize.addEventListener('input', (e) => {
      this.brushSizeValue.textContent = e.target.value;
    });
  }

  setupBrushPreview() {
    const preview = document.createElement('div');
    preview.className = 'preview-pixel';
    document.body.appendChild(preview);

    this.canvas.addEventListener('mousemove', (e) => {
      if (this.currentTool === 'fill') return;
      
      const size = parseInt(this.brushSize.value) * 12;
      preview.style.width = size + 'px';
      preview.style.height = size + 'px';
      preview.style.backgroundColor = this.currentTool === 'eraser' ? 'white' : this.currentColor;
      preview.style.display = 'block';
      
      const rect = this.canvas.getBoundingClientRect();
      const x = e.clientX - size / 2;
      const y = e.clientY - size / 2;
      preview.style.left = x + 'px';
      preview.style.top = y + 'px';
    });

    this.canvas.addEventListener('mouseleave', () => {
      preview.style.display = 'none';
    });
  }

  setTool(tool) {
    this.currentTool = tool;
    [this.pencilBtn, this.eraserBtn, this.fillBucketBtn].forEach(btn => {
      btn.classList.remove('active');
    });
    
    switch(tool) {
      case 'pencil':
        this.pencilBtn.classList.add('active');
        break;
      case 'eraser':
        this.eraserBtn.classList.add('active');
        break;
      case 'fill':
        this.fillBucketBtn.classList.add('active');
        break;
    }
  }

  addToColorHistory(color) {
    if (!this.colorHistoryArray.includes(color)) {
      this.colorHistoryArray.unshift(color);
      if (this.colorHistoryArray.length > 10) {
        this.colorHistoryArray.pop();
      }
      this.updateColorHistory();
    }
  }

  updateColorHistory() {
    this.colorHistory.innerHTML = '';
    this.colorHistoryArray.forEach(color => {
      const swatch = document.createElement('div');
      swatch.className = 'color-swatch';
      swatch.style.backgroundColor = color;
      swatch.addEventListener('click', () => {
        this.currentColor = color;
        this.colorPicker.value = color;
        this.setTool('pencil');
      });
      this.colorHistory.appendChild(swatch);
    });
  }

  createCanvas(size) {
    this.canvas.innerHTML = '';
    this.canvas.style.gridTemplateColumns = `repeat(${size}, 12px)`;
    
    for (let i = 0; i < size * size; i++) {
      const pixel = document.createElement('div');
      pixel.classList.add('pixel');
      
      pixel.addEventListener('mouseover', (e) => {
        if (this.isDrawing && this.currentTool !== 'fill') {
          this.paintArea(e.target);
        }
      });
      
      pixel.addEventListener('mousedown', (e) => {
        if (this.currentTool === 'fill') {
          this.floodFill(e.target);
        } else {
          this.paintArea(e.target);
        }
      });
      
      this.canvas.appendChild(pixel);
    }
  }

  paintArea(centerPixel) {
    const brushSize = parseInt(this.brushSize.value);
    const size = parseInt(this.sizeSelect.value);
    const pixels = Array.from(this.canvas.children);
    const centerIndex = pixels.indexOf(centerPixel);
    
    const row = Math.floor(centerIndex / size);
    const col = centerIndex % size;
    
    for (let i = -Math.floor(brushSize/2); i < Math.ceil(brushSize/2); i++) {
      for (let j = -Math.floor(brushSize/2); j < Math.ceil(brushSize/2); j++) {
        const newRow = row + i;
        const newCol = col + j;
        
        if (newRow >= 0 && newRow < size && newCol >= 0 && newCol < size) {
          const index = newRow * size + newCol;
          const pixel = pixels[index];
          if (pixel) {
            pixel.style.backgroundColor = this.currentTool === 'eraser' ? 'white' : this.currentColor;
          }
        }
      }
    }
  }

  floodFill(startPixel) {
    const targetColor = startPixel.style.backgroundColor || 'white';
    const replacementColor = this.currentColor;
    if (targetColor === replacementColor) return;
    
    const pixels = Array.from(this.canvas.children);
    const size = parseInt(this.sizeSelect.value);
    const stack = [startPixel];
    
    while (stack.length) {
      const pixel = stack.pop();
      const index = pixels.indexOf(pixel);
      
      if (pixel.style.backgroundColor === targetColor) {
        pixel.style.backgroundColor = replacementColor;
        
        // Add adjacent pixels
        const row = Math.floor(index / size);
        const col = index % size;
        
        // Check adjacent pixels (up, right, down, left)
        const adjacent = [
          index - size, // up
          col < size - 1 ? index + 1 : -1, // right
          index + size, // down
          col > 0 ? index - 1 : -1 // left
        ];
        
        adjacent.forEach(idx => {
          if (idx >= 0 && idx < pixels.length) {
            const adjacentPixel = pixels[idx];
            if (adjacentPixel && adjacentPixel.style.backgroundColor === targetColor) {
              stack.push(adjacentPixel);
            }
          }
        });
      }
    }
  }

  setupThemeToggle() {
    this.themeToggle.addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
      const icon = this.themeToggle.querySelector('i');
      if (document.body.classList.contains('dark-mode')) {
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
      } else {
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
      }
    });
  }

  clearCanvas() {
    const pixels = this.canvas.getElementsByClassName('pixel');
    Array.from(pixels).forEach(pixel => {
      pixel.style.backgroundColor = 'white';
    });
  }

  saveAsPNG() {
    // Create a temporary canvas for the export
    const tempCanvas = document.createElement('canvas');
    const pixelSize = 10; // Size of each pixel in the exported image
    const gridSize = parseInt(this.sizeSelect.value);
    
    tempCanvas.width = gridSize * pixelSize;
    tempCanvas.height = gridSize * pixelSize;
    const ctx = tempCanvas.getContext('2d');
    
    // Draw each pixel to the canvas
    const pixels = Array.from(this.canvas.children);
    pixels.forEach((pixel, index) => {
      const row = Math.floor(index / gridSize);
      const col = index % gridSize;
      const color = pixel.style.backgroundColor || 'white';
      
      ctx.fillStyle = color;
      ctx.fillRect(col * pixelSize, row * pixelSize, pixelSize, pixelSize);
    });
    
    // Create download link
    const link = document.createElement('a');
    link.download = 'pixel-art.png';
    link.href = tempCanvas.toDataURL('image/png');
    link.click();
  }
}

// Initialize the app
document.addEventListener('DOMContentLoaded', () => {
  new PixelDrawingApp();
});