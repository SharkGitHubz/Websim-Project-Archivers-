class Calculator {
  constructor() {
    this.value = '0';
    this.previousValue = null;
    this.operator = null;
    this.shouldResetDisplay = false;
    
    this.display = document.querySelector('.value');
    this.bindEvents();
  }

  bindEvents() {
    document.querySelectorAll('button').forEach(button => {
      button.addEventListener('click', () => {
        const digit = button.dataset.digit;
        const action = button.dataset.action;
        
        if (digit !== undefined) {
          this.handleDigit(digit);
        } else if (action) {
          this.handleAction(action);
        }
        
        this.updateDisplay();
      });
    });
  }

  handleDigit(digit) {
    if (this.shouldResetDisplay) {
      this.value = '0';
      this.shouldResetDisplay = false;
    }
    
    if (digit === '.' && this.value.includes('.')) return;
    
    // Check if adding the digit would exceed 15 characters
    if (this.value.replace(/[.-]/g, '').length >= 15 && digit !== '.') return;
    
    if (this.value === '0' && digit !== '.') {
      this.value = digit;
    } else {
      this.value += digit;
    }
  }

  handleAction(action) {
    switch (action) {
      case 'clear':
        this.clear();
        break;
      case 'toggle-sign':
        this.toggleSign();
        break;
      case 'percentage':
        this.percentage();
        break;
      case 'equals':
        this.calculate();
        break;
      default:
        this.handleOperator(action);
    }
  }

  clear() {
    this.value = '0';
    this.previousValue = null;
    this.operator = null;
  }

  toggleSign() {
    this.value = (parseFloat(this.value) * -1).toString();
  }

  percentage() {
    this.value = (parseFloat(this.value) / 100).toString();
  }

  handleOperator(operator) {
    if (this.previousValue !== null) {
      this.calculate();
    }
    
    this.previousValue = parseFloat(this.value);
    this.operator = operator;
    this.shouldResetDisplay = true;
  }

  calculate() {
    if (this.previousValue === null || this.operator === null) return;
    
    const current = parseFloat(this.value);
    let result;
    
    switch (this.operator) {
      case 'add':
        result = this.previousValue + current;
        break;
      case 'subtract':
        result = this.previousValue - current;
        break;
      case 'multiply':
        result = this.previousValue * current;
        break;
      case 'divide':
        result = this.previousValue / current;
        break;
    }
    
    this.value = this.formatResult(result);
    this.previousValue = null;
    this.operator = null;
    this.shouldResetDisplay = true;
  }

  formatResult(number) {
    if (!isFinite(number)) return 'Error';
    
    const stringNumber = number.toString();
    if (stringNumber.replace(/[.-]/g, '').length > 15) {
      // Convert to scientific notation with enough precision to stay under 15 chars
      return number.toExponential(9);
    }
    return stringNumber;
  }

  updateDisplay() {
    this.display.textContent = this.value;
  }
}

new Calculator();